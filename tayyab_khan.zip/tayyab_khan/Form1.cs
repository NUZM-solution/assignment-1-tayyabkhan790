using System.Data;

namespace tayyab_khan
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }
        public void createnewrow()
        {
            if (dt.Rows.Count <= 0)
            {

                DataColumn dc1 = new DataColumn("course code", typeof(string));
                DataColumn dc2 = new DataColumn("course title", typeof(string));
                DataColumn dc3 = new DataColumn("obtained marks", typeof(string));
                DataColumn dc4 = new DataColumn("grade", typeof(string));
                DataColumn dc5 = new DataColumn("ststus", typeof(string));


                dt.Columns.Add(dc1);
                dt.Columns.Add(dc2);
                dt.Columns.Add(dc3);
                dt.Columns.Add(dc4);
                dt.Columns.Add(dc5);



                dt.Rows.Add(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text);


                dataGridView1.DataSource = dt;

            }
            else
            {

                dt.Rows.Add(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text);


                dataGridView1.DataSource = dt;

            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            createnewrow();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

namespace tayyab_login_form
{
    public partial class Form1 : Form
    {
        private int count = 0;
        private int maxcount = 3;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user, password;
            user = "tayyab";
            password = "22011556-071";
            if ((textBox1.Text == user) && (textBox2.Text == password))
            {
                MessageBox.Show("welcome User");
            }
            else
            {
                count++;
                int remain = maxcount - count;
                MessageBox.Show("Wrong user name or password" + "\t" + remain + "" + "tries left");
                textBox2.Clear();
                textBox1.Clear();
                textBox1.Focus();
                if (count >= maxcount)
                {
                    MessageBox.Show("Max try exceeded.");
                    Application.Exit();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear(); // Clear the username textbox
            textBox2.Clear(); // Clear the password textbox
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}

